package com.cunchen.analyzer;

public abstract class Analyzer {

}
